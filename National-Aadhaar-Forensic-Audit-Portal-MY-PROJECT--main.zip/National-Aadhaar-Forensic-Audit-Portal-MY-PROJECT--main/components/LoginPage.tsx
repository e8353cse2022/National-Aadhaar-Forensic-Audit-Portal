
import React, { useState, useEffect } from 'react';
import { LoginData } from '../types';

interface LoginPageProps {
  onLogin: (data: LoginData) => void;
}

type LoginMode = 'login' | 'register';

interface AdminAccount {
  aadhaar: string;
  pin: string;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [mode, setMode] = useState<LoginMode>('login');
  const [securityPin, setSecurityPin] = useState(''); 
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Human Verification State
  const [num1, setNum1] = useState(0);
  const [num2, setNum2] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [verificationError, setVerificationError] = useState(false);

  const [regId, setRegId] = useState('');
  const [regAadhaar, setRegAadhaar] = useState('');

  const generateChallenge = () => {
    setNum1(Math.floor(Math.random() * 10) + 1);
    setNum2(Math.floor(Math.random() * 10) + 1);
    setUserAnswer('');
    setVerificationError(false);
  };

  useEffect(() => {
    generateChallenge();
  }, [mode]);

  const getRegistry = (): Record<string, AdminAccount> => {
    const registry = localStorage.getItem('afa_admin_registry_v2');
    return registry ? JSON.parse(registry) : { 
      "default.auditor": { aadhaar: "000000000000", pin: "123456" } 
    };
  };

  const addToRegistry = (id: string, aadhaarNum: string, pin: string) => {
    const registry = getRegistry();
    registry[pin] = { aadhaar: aadhaarNum, pin };
    localStorage.setItem('afa_admin_registry_v2', JSON.stringify(registry));
  };

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (securityPin.length !== 6) {
      setError('Please type your full 6-digit PIN.');
      return;
    }

    // Human Verification Check
    if (parseInt(userAnswer) !== (num1 + num2)) {
      setError('Human verification failed. Please check the sum.');
      setVerificationError(true);
      return;
    }

    setIsProcessing(true);
    
    setTimeout(() => {
      const registry = getRegistry();
      const account = Object.values(registry).find(acc => acc.pin === securityPin);

      if (account) {
        const identifier = Object.keys(registry).find(key => registry[key].pin === securityPin) || 'Staff Member';
        onLogin({ identifier, aadhaar: account.aadhaar });
      } else {
        setError('Wrong PIN. Please try again.');
        setIsProcessing(false);
        setSecurityPin('');
        generateChallenge(); // Refresh on failure
      }
    }, 800);
  };

  const handleRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (securityPin.length !== 6) {
      setError('Your PIN must be 6 numbers long.');
      return;
    }

    // Human Verification Check for Registration
    if (parseInt(userAnswer) !== (num1 + num2)) {
      setError('Human verification failed. Please try again.');
      setVerificationError(true);
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      addToRegistry(regId || 'Staff Member', regAadhaar || '000000000000', securityPin);
      setSuccessMsg('PIN saved! You can now log in.');
      setMode('login');
      setIsProcessing(false);
      setSecurityPin('');
    }, 1000);
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] px-4 py-12">
      <div className="w-full max-w-[420px] bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 overflow-hidden">
        <div className="uidai-tricolor h-2 w-full"></div>
        
        <div className="p-10">
          <div className="text-center mb-10">
            <div className="inline-block p-4 bg-slate-50 rounded-3xl mb-6 shadow-inner">
              <img 
                src="https://upload.wikimedia.org/wikipedia/en/thumb/c/cf/Aadhaar_Logo.svg/1200px-Aadhaar_Logo.svg.png" 
                alt="Aadhaar" 
                className="h-14 mx-auto"
              />
            </div>
            <h1 className="text-2xl font-black text-slate-900 tracking-tight">Portal Secure Login</h1>
            <p className="text-[10px] text-slate-400 mt-2 font-black uppercase tracking-[0.2em]">
              {mode === 'login' ? 'Authorized Personnel Only' : 'Create Access PIN'}
            </p>
          </div>

          {successMsg && (
            <div className="mb-6 p-4 bg-emerald-50 text-emerald-700 text-[10px] font-black rounded-2xl border border-emerald-100 flex items-center gap-3 uppercase tracking-wider">
              <i className="fas fa-check-circle text-lg"></i> 
              <span>{successMsg}</span>
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 bg-rose-50 text-rose-600 text-[10px] font-black rounded-2xl border border-rose-100 flex items-center gap-3 uppercase tracking-wider animate-shake">
              <i className="fas fa-circle-exclamation text-lg"></i> 
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={mode === 'login' ? handlePinLogin : handleRegistration} className="space-y-6">
            {mode === 'register' && (
              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Staff Identifier</label>
                <input 
                  type="text" 
                  required 
                  className="form-control-uidai py-3 bg-slate-50 border-slate-100 font-bold"
                  placeholder="Enter Name or ID"
                  value={regId}
                  onChange={(e) => setRegId(e.target.value)}
                />
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Secure PIN</label>
              <input 
                type="password" 
                required 
                maxLength={6}
                autoFocus={mode === 'login'}
                className="w-full text-center text-4xl font-mono font-black tracking-[0.6em] py-5 bg-slate-50 border-2 border-slate-100 rounded-3xl focus:border-[#005dab] focus:bg-white outline-none transition-all shadow-inner placeholder:text-slate-200"
                placeholder="••••••"
                value={securityPin}
                onChange={(e) => setSecurityPin(e.target.value.replace(/\D/g, ''))}
              />
            </div>

            {/* Human Verification Box */}
            <div className={`p-5 rounded-3xl border-2 transition-all ${verificationError ? 'bg-rose-50 border-rose-100' : 'bg-slate-50 border-slate-100'}`}>
              <div className="flex justify-between items-center mb-3">
                <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Human Verification</label>
                <button type="button" onClick={generateChallenge} className="text-blue-500 hover:text-blue-700">
                  <i className="fas fa-rotate text-xs"></i>
                </button>
              </div>
              <div className="flex items-center gap-4">
                <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-3 text-center shadow-sm select-none">
                  <span className="text-lg font-black text-slate-800 tracking-widest">
                    {num1} + {num2} = ?
                  </span>
                </div>
                <div className="w-24">
                  <input 
                    type="text" 
                    required 
                    maxLength={2}
                    placeholder="Ans"
                    className="w-full text-center py-3 bg-white border border-slate-200 rounded-2xl font-black text-lg focus:border-[#005dab] outline-none shadow-sm"
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value.replace(/\D/g, ''))}
                  />
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isProcessing}
              className="w-full uidai-button py-5 shadow-xl shadow-blue-900/10 font-black text-xs uppercase tracking-[0.3em] h-16 rounded-3xl"
            >
              {isProcessing ? <i className="fas fa-circle-notch fa-spin text-lg"></i> : <span>{mode === 'login' ? 'Secure Sign In' : 'Register Securely'}</span>}
            </button>

            <div className="text-center pt-4">
              <button 
                type="button" 
                onClick={() => { 
                  setMode(mode === 'login' ? 'register' : 'login'); 
                  setError(''); 
                  setSuccessMsg(''); 
                  setSecurityPin(''); 
                }} 
                className="text-[10px] font-black text-[#005dab] uppercase tracking-widest hover:underline opacity-60 hover:opacity-100"
              >
                {mode === 'login' ? 'Request New Account' : 'Back to Login'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
