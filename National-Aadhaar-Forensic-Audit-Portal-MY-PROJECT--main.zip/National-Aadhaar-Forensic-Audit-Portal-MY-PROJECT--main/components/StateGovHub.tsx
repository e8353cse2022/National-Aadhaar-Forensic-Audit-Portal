
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { AadhaarDataRow } from '../types';

interface StateGovHubProps {
  selectedPerson: AadhaarDataRow | null;
  onClearSelection: () => void;
}

export const StateGovHub: React.FC<StateGovHubProps> = ({ selectedPerson, onClearSelection }) => {
  const [intel, setIntel] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const officialLinks = [
    { title: "UIDAI Official Site", url: "https://uidai.gov.in/", icon: "fa-house-chimney" },
    { title: "MyAadhaar Portal", url: "https://myaadhaar.uidai.gov.in/", icon: "fa-user-lock" },
    { title: "Verify Aadhaar", url: "https://myaadhaar.uidai.gov.in/verifyAadhaar", icon: "fa-user-check" },
    { title: "Bank Seeding Status", url: "https://myaadhaar.uidai.gov.in/check-aadhaar-bank-seeding-status", icon: "fa-building-columns" },
    { title: "Lock Biometrics", url: "https://myaadhaar.uidai.gov.in/lock-unlock-aadhaar", icon: "fa-fingerprint" },
    { title: "Update History", url: "https://myaadhaar.uidai.gov.in/aadhaar-update-history", icon: "fa-clock-rotate-left" },
    { title: "Retrieve EID/UID", url: "https://myaadhaar.uidai.gov.in/retrieve-eid-uid", icon: "fa-key" },
    { title: "Aadhaar App (PlayStore)", url: "https://play.google.com/store/apps/details?id=in.gov.uidai.mAadhaarPlus", icon: "fa-mobile-screen" }
  ];

  const getSourceName = (title: string, uri: string) => {
    if (title.includes(' - ')) return title.split(' - ').pop();
    if (title.includes(' | ')) return title.split(' | ').pop();
    try {
      const hostname = new URL(uri).hostname;
      return hostname.replace('www.', '');
    } catch {
      return 'State Resource';
    }
  };

  const fetchPersonStateIntel = async (person: AadhaarDataRow) => {
    setLoading(true);
    setIntel(null);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `Analyze the state and district for this person context:
    State: ${person.state}
    District: ${person.district}
    
    Provide:
    1. Direct links to the State Government Aadhaar cell or IT Department for ${person.state}.
    2. Latest reports or news about Aadhaar enrollment problems, scams, or issues specifically in ${person.district} or ${person.state}. Mention the newspaper or source for each.
    3. Official Aadhaar help centers in this particular state.
    
    Use very simple, helpful language. Provide clickable URLs where possible.`;

    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }]
        }
      });
      setIntel({
        text: response.text,
        links: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
      });
    } catch (err) {
      console.error("Person state search failed", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedPerson) {
      fetchPersonStateIntel(selectedPerson);
    }
  }, [selectedPerson]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Main Links Sidebar */}
        <div className="md:col-span-4 space-y-6">
          <div className="uidai-card p-5 border-t-4 border-t-[#005dab]">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Official Aadhaar Links</h3>
            <div className="grid grid-cols-1 gap-2">
              {officialLinks.map((link, idx) => (
                <a 
                  key={idx} 
                  href={link.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="p-3 border rounded-lg hover:bg-blue-50 transition-all flex items-center gap-4 group"
                >
                  <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-[#005dab] group-hover:bg-white transition-colors">
                    <i className={`fas ${link.icon} text-xs`}></i>
                  </div>
                  <span className="text-[10px] font-black text-slate-700 uppercase">{link.title}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Person Specific Intel */}
        <div className="md:col-span-8">
          <div className="uidai-card min-h-[400px] flex flex-col">
            <div className="p-6 border-b flex justify-between items-center bg-slate-50/50">
              <div>
                <h2 className="text-lg font-black text-slate-800 tracking-tight">State Government Info</h2>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Custom Reports & Regional Portals</p>
              </div>
              {selectedPerson && (
                <button onClick={onClearSelection} className="text-[9px] font-black text-rose-500 uppercase border border-rose-200 px-3 py-1 rounded-full hover:bg-rose-50 transition-colors">
                  <i className="fas fa-xmark mr-1"></i> Clear Selection
                </button>
              )}
            </div>

            <div className="p-6 flex-1">
              {!selectedPerson ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-20 opacity-40">
                  <i className="fas fa-user-tag text-5xl mb-4 text-slate-200"></i>
                  <h4 className="text-sm font-black text-slate-500 uppercase">No Person Selected</h4>
                  <p className="text-[10px] font-bold max-w-xs mt-2">Go to the Audit Home and click "Check State" on a record to see custom state news and reports here.</p>
                </div>
              ) : loading ? (
                <div className="h-full flex flex-col items-center justify-center py-20 space-y-4">
                  <div className="w-10 h-10 border-4 border-blue-100 border-t-[#005dab] rounded-full animate-spin"></div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Finding News for {selectedPerson.district}...</p>
                </div>
              ) : intel ? (
                <div className="space-y-6">
                  <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-100 flex items-center gap-4">
                    <div className="text-emerald-700">
                      <i className="fas fa-location-dot text-xl"></i>
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-emerald-800 uppercase tracking-tight">Active Context</p>
                      <p className="text-sm font-black text-emerald-900">{selectedPerson.district}, {selectedPerson.state}</p>
                    </div>
                  </div>

                  <div className="prose prose-slate max-w-none">
                    <div className="p-5 bg-white border border-slate-100 rounded-xl text-xs leading-relaxed font-medium text-slate-600 whitespace-pre-wrap shadow-sm">
                      {intel.text}
                    </div>
                  </div>

                  {intel.links && intel.links.length > 0 && (
                    <div className="border-t pt-6">
                      <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-4">Official Sources Found</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {intel.links.map((link: any, i: number) => {
                          const web = link.web;
                          const maps = link.maps;
                          if (!web && !maps) return null;
                          const title = web?.title || maps?.title || 'Source';
                          const uri = web?.uri || maps?.uri || '#';
                          const source = getSourceName(title, uri);

                          return (
                            <a 
                              key={i} 
                              href={uri} 
                              target="_blank" 
                              rel="noopener noreferrer" 
                              className="p-4 border border-slate-100 bg-white rounded-xl hover:bg-blue-50 transition-all flex flex-col justify-between group h-28"
                            >
                              <div>
                                <div className="flex items-center gap-2 mb-1">
                                  <i className={`fas ${maps ? 'fa-location-dot text-rose-500' : 'fa-newspaper text-blue-500'} text-[8px]`}></i>
                                  <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{source}</span>
                                </div>
                                <h5 className="text-[9px] font-black text-slate-700 uppercase line-clamp-2 leading-tight group-hover:text-[#005dab]">{title}</h5>
                              </div>
                              <div className="flex items-center justify-between text-[7px] font-bold text-slate-400 uppercase mt-2 pt-2 border-t border-slate-50">
                                <span>Check Source</span>
                                <i className="fas fa-arrow-up-right-from-square"></i>
                              </div>
                            </a>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                 <div className="h-full flex flex-col items-center justify-center text-center py-20">
                    <p className="text-[10px] font-black text-slate-400 uppercase">Failed to load reports. Try again.</p>
                 </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
