
import React, { useState, useEffect, useMemo } from 'react';
import { AadhaarDataRow, ActionRecord } from '../types';
import { draftSimpleNotice } from '../services/geminiService';

interface ActionCenterProps {
  person: AadhaarDataRow | null;
  reasons: string[];
  history: ActionRecord[];
  onFinish: (record: ActionRecord) => void;
  onUpdateStatus: (id: string, status: 'fixed') => void;
  onCancel: () => void;
}

export const ActionCenter: React.FC<ActionCenterProps> = ({ person, reasons, history, onFinish, onUpdateStatus, onCancel }) => {
  const [loadingNotice, setLoadingNotice] = useState(false);
  const [noticeDraft, setNoticeDraft] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [filter, setFilter] = useState<'all' | 'waiting' | 'fixed'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (person) {
      setLoadingNotice(true);
      draftSimpleNotice(person, reasons).then(notice => {
        setNoticeDraft(notice || '');
        setLoadingNotice(false);
      });
    }
  }, [person, reasons]);

  const handleAction = (type: ActionRecord['actionType']) => {
    setIsProcessing(true);
    setTimeout(() => {
      const record: ActionRecord = {
        id: Math.random().toString(36).substr(2, 9),
        person: person!,
        actionType: type,
        timestamp: new Date().toLocaleString(),
        notes: noticeDraft,
        status: 'waiting'
      };
      setSuccess(true);
      setTimeout(() => {
        onFinish(record);
        setSuccess(false);
        setIsProcessing(false);
      }, 1500);
    }, 1000);
  };

  const filteredHistory = useMemo(() => {
    return history.filter(item => {
      const matchesFilter = filter === 'all' || item.status === filter;
      const matchesSearch = item.person.district.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            item.person.state.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesFilter && matchesSearch;
    });
  }, [history, filter, searchQuery]);

  const stats = {
    total: history.length,
    waiting: history.filter(h => h.status === 'waiting').length,
    fixed: history.filter(h => h.status === 'fixed').length
  };

  return (
    <div className="max-w-5xl mx-auto py-6 space-y-8 animate-in fade-in duration-500 pb-20">
      {/* SECTION 1: Status Counters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="uidai-card p-6 bg-white border-b-4 border-b-slate-200">
           <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Actions</p>
           <h3 className="text-3xl font-black text-slate-800">{stats.total}</h3>
        </div>
        <div className="uidai-card p-6 bg-white border-b-4 border-b-amber-400">
           <p className="text-[9px] font-black text-amber-500 uppercase tracking-widest mb-1">Still Waiting</p>
           <h3 className="text-3xl font-black text-slate-800">{stats.waiting}</h3>
        </div>
        <div className="uidai-card p-6 bg-white border-b-4 border-b-emerald-500">
           <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Finished / Solved</p>
           <h3 className="text-3xl font-black text-slate-800">{stats.fixed}</h3>
        </div>
      </div>

      {/* SECTION 2: Take New Action Form */}
      {person && (
        <div className="uidai-card bg-white overflow-hidden shadow-2xl animate-in slide-in-from-top-4 border-2 border-blue-100">
          <div className="p-8 border-b bg-blue-50/30 flex justify-between items-center">
             <div>
                <h2 className="text-2xl font-black text-slate-800 tracking-tight">Report a New Problem</h2>
                <p className="text-[10px] font-black text-[#005dab] uppercase tracking-widest mt-1">Start a fix for this person</p>
             </div>
             <button onClick={onCancel} className="text-[10px] font-black text-slate-400 hover:text-slate-600 uppercase border bg-white px-4 py-2 rounded-full shadow-sm">
                Close
             </button>
          </div>

          <div className="p-8 space-y-8">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                   <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Area Info</p>
                      <div className="space-y-2">
                         <p className="text-sm font-black text-slate-800 uppercase">{person.district}, {person.state}</p>
                         <p className="text-[10px] font-bold text-slate-500 uppercase">Pincode: {person.pincode}</p>
                      </div>
                      <div className="mt-4 pt-4 border-t border-slate-200">
                         <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">The Mistake</p>
                         <div className="flex flex-wrap gap-2">
                            {reasons.map((r, i) => (
                              <span key={i} className="bg-[#005dab] px-3 py-1 rounded-full text-[9px] font-black text-white uppercase">{r}</span>
                            ))}
                         </div>
                      </div>
                   </div>

                   <div className="space-y-3">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">The Message to Send</p>
                      <div className="relative">
                         {loadingNotice ? (
                           <div className="h-32 bg-slate-50 animate-pulse rounded-2xl border border-dashed border-slate-200 flex items-center justify-center">
                              <span className="text-[9px] font-black text-slate-300 uppercase">Writing...</span>
                           </div>
                         ) : (
                           <textarea 
                             className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-2xl text-[11px] font-medium text-slate-700 focus:outline-none focus:border-[#005dab] transition-all"
                             value={noticeDraft}
                             onChange={(e) => setNoticeDraft(e.target.value)}
                           />
                         )}
                      </div>
                   </div>
                </div>

                <div className="space-y-4">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">What action to take?</p>
                   
                   {success ? (
                     <div className="h-full flex flex-col items-center justify-center space-y-4 bg-emerald-50 rounded-3xl border border-emerald-100 py-12">
                        <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 animate-bounce">
                           <i className="fas fa-check text-2xl"></i>
                        </div>
                        <p className="text-xs font-black text-emerald-800 uppercase">Saved to Waiting List!</p>
                     </div>
                   ) : (
                     <div className="grid grid-cols-1 gap-4">
                        <button onClick={() => handleAction('message')} disabled={isProcessing} className="group p-6 border-2 border-blue-50 bg-white hover:border-[#005dab] hover:bg-blue-50/30 rounded-3xl text-left transition-all">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-[#005dab] group-hover:bg-[#005dab] group-hover:text-white transition-all">
                                 <i className="fas fa-comment-dots text-lg"></i>
                              </div>
                              <div>
                                 <p className="text-xs font-black text-slate-800 uppercase">Send Notice</p>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">Tell person about mistake</p>
                              </div>
                           </div>
                        </button>
                        <button onClick={() => handleAction('fix')} disabled={isProcessing} className="group p-6 border-2 border-amber-50 bg-white hover:border-amber-400 hover:bg-amber-50/30 rounded-3xl text-left transition-all">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500 group-hover:bg-amber-500 group-hover:text-white transition-all">
                                 <i className="fas fa-wrench text-lg"></i>
                              </div>
                              <div>
                                 <p className="text-xs font-black text-slate-800 uppercase">Fix List</p>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">Send to junior staff</p>
                              </div>
                           </div>
                        </button>
                        <button onClick={() => handleAction('report')} disabled={isProcessing} className="group p-6 border-2 border-rose-50 bg-white hover:border-rose-500 hover:bg-rose-50/30 rounded-3xl text-left transition-all">
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-rose-50 rounded-2xl flex items-center justify-center text-rose-500 group-hover:bg-rose-500 group-hover:text-white transition-all">
                                 <i className="fas fa-triangle-exclamation text-lg"></i>
                              </div>
                              <div>
                                 <p className="text-xs font-black text-slate-800 uppercase">Report Fraud</p>
                                 <p className="text-[9px] font-bold text-slate-400 uppercase">Send to Headquarters</p>
                              </div>
                           </div>
                        </button>
                     </div>
                   )}
                </div>
             </div>
          </div>
        </div>
      )}

      {/* SECTION 3: Action History & Filtering */}
      <div className="uidai-card bg-white shadow-xl overflow-hidden">
        <div className="p-8 border-b bg-slate-50 space-y-6">
           <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                 <h2 className="text-xl font-black text-slate-800 tracking-tight">All Action History</h2>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Check progress and solve issues</p>
              </div>
              <div className="flex items-center p-1 bg-slate-200 rounded-xl">
                 {(['all', 'waiting', 'fixed'] as const).map((f) => (
                   <button 
                     key={f}
                     onClick={() => setFilter(f)}
                     className={`px-4 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all ${filter === f ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                   >
                     {f}
                   </button>
                 ))}
              </div>
           </div>

           <div className="relative">
              <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-300"></i>
              <input 
                type="text" 
                placeholder="Find a report by area name..." 
                className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 rounded-2xl text-xs font-bold uppercase placeholder:text-slate-300 focus:outline-none focus:border-[#005dab]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
           </div>
        </div>

        <div className="divide-y">
           {filteredHistory.length === 0 ? (
             <div className="p-20 text-center opacity-30">
                <i className="fas fa-magnifying-glass text-5xl mb-4"></i>
                <p className="text-xs font-black uppercase tracking-widest">Nothing found</p>
             </div>
           ) : (
             filteredHistory.map((record) => (
               <div key={record.id} className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-start gap-4 flex-1">
                     <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${record.status === 'fixed' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                        <i className={`fas ${record.status === 'fixed' ? 'fa-check-double' : 'fa-clock'} text-lg`}></i>
                     </div>
                     <div className="min-w-0">
                        <div className="flex items-center gap-3 mb-1">
                           <h4 className="text-sm font-black text-slate-800 uppercase truncate">{record.person.district}, {record.person.state}</h4>
                           <span className={`text-[8px] font-black px-2 py-0.5 rounded-full uppercase ${record.actionType === 'report' ? 'bg-rose-50 text-rose-600' : record.actionType === 'fix' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'}`}>
                              {record.actionType}
                           </span>
                        </div>
                        <p className="text-[10px] text-slate-500 font-medium line-clamp-1 italic">"{record.notes}"</p>
                        <p className="text-[8px] font-black text-slate-400 uppercase mt-2 tracking-widest">Reported on {record.timestamp}</p>
                     </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                     <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${record.status === 'fixed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-amber-50 text-amber-700 border-amber-100'}`}>
                        {record.status === 'fixed' ? 'Finished / Solved' : 'Still Waiting'}
                     </div>
                     {record.status === 'waiting' && (
                       <button 
                         onClick={() => onUpdateStatus(record.id, 'fixed')}
                         className="uidai-button h-10 px-6 text-[9px] font-black uppercase tracking-widest bg-slate-900 hover:bg-black shadow-lg"
                       >
                          Solve This
                       </button>
                     )}
                  </div>
               </div>
             ))
           )}
        </div>
      </div>
    </div>
  );
};
