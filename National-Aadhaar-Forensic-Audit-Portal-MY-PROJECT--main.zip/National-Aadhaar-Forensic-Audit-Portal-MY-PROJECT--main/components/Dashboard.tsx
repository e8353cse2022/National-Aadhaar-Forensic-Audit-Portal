
import React, { useState, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { DatasetStats, AnomalyResult, SearchIntel, LocationVerification, AadhaarDataRow } from '../types';

interface DashboardProps {
  fullData: AadhaarDataRow[];
  stats: DatasetStats;
  anomalies: AnomalyResult[];
  aiAnalysis: any;
  aiStatus: 'idle' | 'loading' | 'completed' | 'error';
  onRetryAI: () => void;
  regionalIntel: SearchIntel | null;
  onSearchIntel: (location: string) => void;
  locationVerif: LocationVerification | null;
  onVerifyLocation: (district: string, state: string) => void;
  isVerifying: boolean;
  isSearching: boolean;
  onSelectPerson: (person: AadhaarDataRow) => void;
  onTakeAction: (person: AadhaarDataRow, reasons: string[]) => void;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-2 border border-gray-100 shadow-xl rounded text-[10px]">
        <p className="font-bold text-gray-900 mb-0.5">{label}</p>
        <p className="text-[#005dab] font-bold">Total: {payload[0].value.toLocaleString()}</p>
      </div>
    );
  }
  return null;
};

// Helper to extract a source name from a URL or title
const getSourceName = (title: string, uri: string) => {
  if (title.includes(' - ')) return title.split(' - ').pop();
  if (title.includes(' | ')) return title.split(' | ').pop();
  try {
    const hostname = new URL(uri).hostname;
    return hostname.replace('www.', '');
  } catch {
    return 'News Source';
  }
};

export const Dashboard: React.FC<DashboardProps> = ({ 
  fullData, stats, anomalies, aiAnalysis, aiStatus, onRetryAI, 
  regionalIntel, onSearchIntel, locationVerif, onVerifyLocation,
  isVerifying, isSearching, onSelectPerson, onTakeAction
}) => {
  const [activeTab, setActiveTab] = useState<'stats' | 'intel' | 'records'>('stats');
  const [searchTerm, setSearchTerm] = useState('');
  const [visibleAnomaliesCount, setVisibleAnomaliesCount] = useState(25);
  const [expandedAnomalyIndex, setExpandedAnomalyIndex] = useState<number | null>(null);

  const filteredFullData = useMemo(() => {
    if (!searchTerm) return fullData.slice(0, 100);
    return fullData.filter(row => 
      Object.values(row).some(val => 
        String(val).toLowerCase().includes(searchTerm.toLowerCase())
      )
    ).slice(0, 100);
  }, [fullData, searchTerm]);

  const openMap = (row: AadhaarDataRow) => {
    const query = encodeURIComponent(`${row.district || ''}, ${row.state || ''}, ${row.pincode || ''}`.trim());
    window.open(`https://www.google.com/maps/search/?api=1&query=${query}`, '_blank');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Items', value: stats?.totalRows?.toLocaleString(), color: '#005dab', icon: 'fa-file-lines' },
          { label: 'Flags Found', value: stats?.anomalyCount?.toLocaleString(), color: '#e53e3e', icon: 'fa-flag' },
          { label: 'Mistake Rate', value: `${stats?.anomalyRate?.toFixed(2)}%`, color: '#d97706', icon: 'fa-chart-simple' },
          { label: 'Places Checked', value: stats?.topStates?.length, color: '#059669', icon: 'fa-location-crosshairs' },
        ].map((card, idx) => (
          <div key={idx} className="uidai-card p-4 bg-white border-b-2" style={{ borderBottomColor: card.color }}>
            <div className="flex items-center gap-2 mb-2 opacity-50">
               <i className={`fas ${card.icon} text-[10px]`}></i>
               <span className="text-[9px] font-black uppercase tracking-widest">{card.label}</span>
            </div>
            <p className="text-2xl font-black text-gray-900 tracking-tighter">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-6">
          <div className="uidai-card overflow-hidden">
            <div className="flex bg-gray-50 border-b">
              {[
                { id: 'stats', label: 'Charts', icon: 'fa-chart-area' },
                { id: 'intel', label: 'News Desk', icon: 'fa-newspaper' },
                { id: 'records', label: 'All Items', icon: 'fa-list' }
              ].map((tab) => (
                <button 
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-2 px-6 py-3.5 text-[10px] font-extrabold uppercase tracking-widest border-r transition-all ${activeTab === tab.id ? 'bg-white text-[#005dab] border-t-2 border-t-[#005dab]' : 'text-gray-400 hover:bg-white'}`}
                >
                  <i className={`fas ${tab.icon}`}></i> {tab.label}
                </button>
              ))}
            </div>
            <div className="p-6">
              {activeTab === 'stats' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="h-[240px]">
                      <h4 className="text-[9px] font-black uppercase tracking-[0.2em] text-[#005dab] mb-4">Flags by State</h4>
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={stats?.topStates || []} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f0f0f0" />
                          <XAxis type="number" hide />
                          <YAxis dataKey="name" type="category" width={80} tick={{ fontSize: 8, fontWeight: 900, fill: '#666' }} axisLine={false} tickLine={false} />
                          <Tooltip content={<CustomTooltip />} />
                          <Bar dataKey="value" fill="#005dab" radius={[0, 2, 2, 0]} barSize={14} />
                        </BarChart>
                      </ResponsiveContainer>
                   </div>
                   <div className="h-[240px]">
                      <h4 className="text-[9px] font-black uppercase tracking-[0.2em] text-[#005dab] mb-4">Items Over Time</h4>
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={stats?.timeSeries || []}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis dataKey="date" tick={{ fontSize: 8, fontWeight: 700, fill: '#999' }} axisLine={false} />
                          <YAxis tick={{ fontSize: 8, fontWeight: 700, fill: '#999' }} axisLine={false} />
                          <Tooltip content={<CustomTooltip />} />
                          <Area type="monotone" dataKey="count" stroke="#0090da" strokeWidth={2} fill="#0090da" fillOpacity={0.05} />
                        </AreaChart>
                      </ResponsiveContainer>
                   </div>
                </div>
              )}
              {activeTab === 'intel' && (
                <div className="space-y-6">
                   {!regionalIntel && !isSearching ? (
                     <div className="text-center py-12 bg-blue-50/20 border border-dashed rounded-lg">
                        <i className="fas fa-search-plus text-2xl text-blue-200 mb-3"></i>
                        <h5 className="text-xs font-black text-gray-700 uppercase mb-3">Check Area News</h5>
                        <button onClick={() => onSearchIntel("Aadhaar problems news")} className="uidai-button text-[10px] py-2 px-4 font-black">Find News</button>
                     </div>
                   ) : isSearching ? (
                     <div className="flex flex-col items-center py-12 space-y-3">
                        <div className="w-6 h-6 border-2 border-blue-100 border-t-[#005dab] rounded-full animate-spin"></div>
                        <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Searching Archives...</p>
                     </div>
                   ) : (
                     <div className="space-y-6">
                        <div className="p-6 bg-blue-50/40 border border-[#005dab]/10 rounded-2xl text-[11px] text-slate-700 leading-relaxed font-medium shadow-inner">
                           {regionalIntel?.summary}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                           <h4 className="col-span-full text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
                              <i className="fas fa-book-open"></i> Sources & Papers
                           </h4>
                           {regionalIntel?.links.map((link, idx) => {
                              const web = link.web;
                              if (!web) return null;
                              const source = getSourceName(web.title, web.uri);
                              return (
                                <a key={idx} href={web.uri} target="_blank" rel="noopener noreferrer" className="group p-4 bg-white border border-slate-100 rounded-2xl hover:border-[#005dab] hover:shadow-lg transition-all flex flex-col justify-between h-32">
                                   <div>
                                      <p className="text-[8px] font-black text-[#005dab] uppercase mb-1 tracking-tighter opacity-60">{source}</p>
                                      <h5 className="text-[10px] font-black text-slate-800 line-clamp-2 leading-tight uppercase group-hover:text-[#005dab]">{web.title}</h5>
                                   </div>
                                   <div className="flex items-center justify-between text-[8px] font-black text-slate-400 uppercase border-t pt-2">
                                      <span>Read Article</span>
                                      <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
                                   </div>
                                </a>
                              );
                           })}
                        </div>
                     </div>
                   )}
                </div>
              )}
              {activeTab === 'records' && (
                <div className="space-y-4">
                   <div className="relative">
                      <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-300"></i>
                      <input type="text" placeholder="Search for an item..." className="form-control-uidai pl-10 py-2 uppercase text-[9px] font-black" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
                   </div>
                   <div className="overflow-x-auto border rounded overflow-hidden">
                      <table className="w-full text-left text-[10px]">
                         <thead className="bg-gray-50 text-gray-400 uppercase font-black border-b">
                            <tr>
                               <th className="px-4 py-3">Date</th>
                               <th className="px-4 py-3">District</th>
                               <th className="px-4 py-3">State</th>
                               <th className="px-4 py-3 text-right">Action</th>
                            </tr>
                         </thead>
                         <tbody className="divide-y">
                            {filteredFullData.map((row, i) => (
                              <tr key={i} className="hover:bg-blue-50/30 transition-colors">
                                 <td className="px-4 py-3 font-mono font-bold text-gray-400">{String(row.date)}</td>
                                 <td className="px-4 py-3 font-black text-gray-800">{String(row.district)}</td>
                                 <td className="px-4 py-3 font-bold text-gray-500">{String(row.state)}</td>
                                 <td className="px-4 py-3 text-right flex justify-end gap-2">
                                    <button onClick={() => onSelectPerson(row)} className="text-[#005dab] hover:underline font-black uppercase text-[8px]">State Info</button>
                                    <button onClick={() => onVerifyLocation(row.district, row.state)} className="text-slate-400 hover:text-[#005dab] hover:underline font-black uppercase text-[8px]">Map Check</button>
                                 </td>
                              </tr>
                            ))}
                         </tbody>
                      </table>
                   </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="lg:col-span-4 space-y-6">
           <div className="uidai-card p-6 border-t-4 border-t-[#005dab]">
              <h3 className="text-base font-black text-gray-900 mb-4 flex items-center justify-between">
                 <span>AI Help Report</span>
                 <i className="fas fa-robot text-blue-100"></i>
              </h3>
              {aiStatus === 'loading' ? (
                <div className="py-12 text-center space-y-3">
                   <div className="w-6 h-6 border-2 border-blue-50 border-t-[#005dab] rounded-full animate-spin mx-auto"></div>
                   <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Writing Report...</p>
                </div>
              ) : aiAnalysis ? (
                <div className="space-y-4 overflow-y-auto max-h-[400px] custom-scrollbar pr-1">
                   {aiAnalysis.patterns.map((p: any, i: number) => (
                     <div key={i} className="p-3 bg-gray-50 rounded border-l-2 border-l-[#005dab]">
                        <p className="text-[10px] font-black text-[#005dab] uppercase mb-0.5">{p.title}</p>
                        <p className="text-[9px] text-gray-600 font-medium leading-normal">{p.description}</p>
                     </div>
                   ))}
                </div>
              ) : (
                <button onClick={onRetryAI} className="w-full uidai-button-outline text-[10px] py-2 uppercase">Start AI Check</button>
              )}
           </div>
           <div className="uidai-card p-6 bg-[#005dab] text-white">
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-3 flex items-center gap-2">
                 <i className="fas fa-circle-info"></i> Note
              </h4>
              <p className="text-[10px] font-bold opacity-80 leading-normal mb-4 uppercase">Look at the flagged items and report any big problems.</p>
           </div>
        </div>
      </div>

      <div className="uidai-card bg-white shadow-lg">
        <div className="p-6 border-b flex justify-between items-center">
           <div>
              <h3 className="text-xl font-black text-gray-800 tracking-tight">Mistakes Found</h3>
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mt-0.5">List of items that have mistakes or look odd</p>
           </div>
           <button className="uidai-button-outline flex items-center gap-2 text-[10px] py-2">
              <i className="fas fa-download"></i> Save Report
           </button>
        </div>
        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead className="bg-gray-50 text-[9px] font-black text-gray-400 uppercase tracking-widest border-b">
                 <tr>
                    <th className="px-6 py-4">Score</th>
                    <th className="px-6 py-4">Area</th>
                    <th className="px-6 py-4">Flag Reason</th>
                    <th className="px-6 py-4 text-right">Action</th>
                 </tr>
              </thead>
              <tbody className="divide-y">
                 {anomalies.slice(0, visibleAnomaliesCount).map((anomaly, idx) => (
                   <React.Fragment key={idx}>
                     <tr className="hover:bg-blue-50/20 cursor-pointer transition-all" onClick={() => setExpandedAnomalyIndex(expandedAnomalyIndex === idx ? null : idx)}>
                        <td className="px-6 py-5">
                           <div className="flex items-center gap-3">
                              <div className="w-16 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                 <div className={`h-full ${anomaly.score > 0.8 ? 'bg-red-500' : 'bg-[#005dab]'}`} style={{ width: `${anomaly.score*100}%` }}></div>
                              </div>
                              <span className="text-[10px] font-black text-gray-700">{(anomaly.score*100).toFixed(0)}%</span>
                           </div>
                        </td>
                        <td className="px-6 py-5">
                           <div className="text-xs font-black text-gray-900 uppercase">{anomaly.row.district}</div>
                           <div className="text-[8px] text-gray-400 font-bold uppercase">{anomaly.row.state}</div>
                        </td>
                        <td className="px-6 py-5">
                           <span className="text-[8px] font-black text-[#005dab] bg-blue-50 px-1.5 py-0.5 rounded uppercase">
                              {anomaly.detailedReasons[0]?.feature.toUpperCase()}
                           </span>
                        </td>
                        <td className="px-6 py-5 text-right">
                           <div className="flex justify-end gap-3 items-center">
                              <button 
                                onClick={(e) => { e.stopPropagation(); onTakeAction(anomaly.row, anomaly.reasons); }}
                                className="bg-[#005dab] text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-tight hover:bg-blue-600 transition-colors shadow-lg shadow-blue-900/10"
                              >
                                Take Action
                              </button>
                              <i className={`fas fa-chevron-${expandedAnomalyIndex === idx ? 'up' : 'down'} text-[10px] text-gray-300`}></i>
                           </div>
                        </td>
                     </tr>
                     {expandedAnomalyIndex === idx && (
                       <tr className="bg-gray-50/50">
                          <td colSpan={4} className="p-6">
                             <div className="uidai-card p-6 bg-white shadow-xl space-y-6 border-2 border-blue-50">
                                <div className="flex justify-between items-center">
                                  <h5 className="text-xs font-black text-[#005dab] uppercase tracking-tighter flex items-center gap-2">
                                     <i className="fas fa-eye"></i> Why we flagged this
                                  </h5>
                                  <button onClick={() => onSelectPerson(anomaly.row)} className="text-[9px] font-black text-white bg-[#005dab] px-4 py-1.5 rounded-full uppercase tracking-tight shadow-md">
                                    View State Info
                                  </button>
                                </div>
                                <div className="grid grid-cols-2 gap-8">
                                   <div className="space-y-4">
                                      <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Mistakes Found</p>
                                      {anomaly.detailedReasons.map((dr, ri) => (
                                        <div key={ri} className="p-3 bg-gray-50 border rounded space-y-1">
                                           <div className="flex justify-between items-center text-[9px] font-black uppercase text-[#005dab]">
                                              <span>{dr.feature}</span>
                                           </div>
                                           <p className="text-[10px] font-semibold text-gray-600 leading-normal">"{dr.explanation}"</p>
                                        </div>
                                      ))}
                                   </div>
                                   <div className="space-y-4">
                                      <div className="flex justify-between items-center">
                                        <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Full Info</p>
                                        <button onClick={() => openMap(anomaly.row)} className="text-[9px] font-black text-[#005dab] uppercase bg-blue-50 px-2 py-0.5 rounded hover:bg-blue-100 flex items-center gap-1.5">
                                          <i className="fas fa-map-location-dot text-[10px]"></i> See Map
                                        </button>
                                      </div>
                                      <div className="grid grid-cols-2 gap-x-4 gap-y-2">
                                         {Object.entries(anomaly.row).map(([k, v]) => (
                                           <div key={k} className="border-b py-0.5">
                                              <span className="text-[7px] font-black text-gray-400 uppercase block">{k}</span>
                                              <span className="text-[10px] font-black text-gray-800 uppercase">{String(v || 'NONE')}</span>
                                           </div>
                                         ))}
                                      </div>
                                   </div>
                                </div>
                             </div>
                          </td>
                       </tr>
                     )}
                   </React.Fragment>
                 ))}
              </tbody>
           </table>
           <div className="p-8 text-center bg-gray-50/30">
              <button onClick={() => setVisibleAnomaliesCount(prev => prev + 25)} className="uidai-button-outline px-10 text-[10px] font-black uppercase tracking-widest py-2">
                 Show More
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};
