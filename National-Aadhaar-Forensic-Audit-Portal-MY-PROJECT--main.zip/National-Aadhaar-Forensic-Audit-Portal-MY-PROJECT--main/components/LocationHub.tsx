
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

export const LocationHub: React.FC = () => {
  const [pincode, setPincode] = useState('283203');
  const [district, setDistrict] = useState('Firozabad');
  const [state, setState] = useState('Uttar Pradesh');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState('');

  const quickLinks = [
    { district: 'Firozabad', state: 'Uttar Pradesh', pincode: '283203', label: 'Firozabad, UP (283203)' },
    { district: 'Pune', state: 'Maharashtra', pincode: '411001', label: 'Pune, MH (411001)' },
    { district: 'Bengaluru', state: 'Karnataka', pincode: '560001', label: 'Bengaluru, KA (560001)' }
  ];

  const handleQuickSearch = (item: typeof quickLinks[0]) => {
    setPincode(item.pincode);
    setDistrict(item.district);
    setState(item.state);
    performSearch(item.pincode, item.district, item.state);
  };

  const performSearch = async (pin: string, dist: string, st: string) => {
    setError('');
    setLoading(true);
    setResult(null);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `Tell me about Aadhaar centers in this area:
    State: ${st}
    District: ${dist}
    Pincode: ${pin}
    
    Tell me:
    1. Where the centers are.
    2. Any news about scams or problems here recently. Identify the news paper or source for each piece of news.
    
    Use very simple, easy language for staff.`;
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
          tools: [{ googleMaps: {} }, { googleSearch: {} }]
        }
      });

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const mapLink = chunks.find((c: any) => c.maps)?.maps?.uri || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${dist}, ${st}, ${pin}`)}`;

      setResult({
        summary: response.text,
        links: chunks,
        mapQuery: `${dist}, ${st}, ${pin}`,
        officialMapUri: mapLink
      });
    } catch (err) {
      console.error("Search error:", err);
      setError("Could not find info. Check your connection.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pincode && !district && !state) {
      setError('Please enter a Pincode or District.');
      return;
    }
    performSearch(pincode, district, state);
  };

  const getSourceName = (title: string, uri: string) => {
    if (title.includes(' - ')) return title.split(' - ').pop();
    if (title.includes(' | ')) return title.split(' | ').pop();
    try {
      const hostname = new URL(uri).hostname;
      return hostname.replace('www.', '');
    } catch {
      return 'News Desk';
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-6 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-12">
          <div className="uidai-card p-10 bg-white border-t-4 border-t-[#005dab] shadow-2xl">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
               <div>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tighter">Area Check</h2>
                  <p className="text-[11px] font-black text-[#005dab] uppercase tracking-[0.3em] mt-2">Find Local Info and Maps</p>
               </div>
               <div className="flex flex-wrap gap-2">
                  <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest self-center mr-2">Quick Links:</span>
                  {quickLinks.map((link, idx) => (
                    <button 
                      key={idx}
                      onClick={() => handleQuickSearch(link)}
                      className={`px-4 py-2 rounded-full text-[10px] font-black transition-all border ${district === link.district ? 'bg-[#005dab] text-white border-[#005dab]' : 'bg-slate-50 text-slate-500 border-slate-100 hover:bg-white hover:border-blue-200'}`}
                    >
                      {link.label}
                    </button>
                  ))}
               </div>
            </div>
            
            <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest ml-1">Pincode</label>
                <input type="text" maxLength={6} className="form-control-uidai py-3.5 px-4 font-mono text-base font-black bg-white" placeholder="283203" value={pincode} onChange={(e) => setPincode(e.target.value.replace(/\D/g, ''))} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest ml-1">District</label>
                <input type="text" className="form-control-uidai py-3.5 px-4 text-sm font-bold bg-white" placeholder="Firozabad" value={district} onChange={(e) => setDistrict(e.target.value)} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest ml-1">State</label>
                <input type="text" className="form-control-uidai py-3.5 px-4 text-sm font-bold bg-white" placeholder="Uttar Pradesh" value={state} onChange={(e) => setState(e.target.value)} />
              </div>
              <div>
                <button type="submit" disabled={loading} className="w-full uidai-button h-[54px] text-xs font-black uppercase tracking-widest shadow-xl shadow-blue-900/10 transition-all hover:scale-[1.02]">
                  {loading ? <i className="fas fa-satellite-dish fa-spin mr-2"></i> : <><i className="fas fa-search mr-2"></i> Check Area</>}
                </button>
              </div>
            </form>

            {error && (
              <div className="mt-6 p-4 bg-rose-50 border border-rose-100 rounded-xl text-[11px] font-bold text-rose-600 flex items-center gap-3">
                <i className="fas fa-circle-exclamation text-lg"></i> {error}
              </div>
            )}
          </div>
        </div>

        {result && (
          <div className="lg:col-span-12 grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in slide-in-from-bottom-6 duration-700">
            <div className="lg:col-span-7 space-y-8">
              <div className="uidai-card bg-white p-8">
                <div className="flex items-center gap-4 mb-8">
                   <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center text-[#005dab]">
                      <i className="fas fa-file-waveform text-xl"></i>
                   </div>
                   <div>
                      <h3 className="text-xl font-black text-slate-900 tracking-tight">Area Report</h3>
                      <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Verified Info</p>
                   </div>
                </div>

                <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 text-sm leading-relaxed font-medium text-slate-700 whitespace-pre-wrap shadow-inner">
                  {result.summary}
                </div>

                <div className="mt-8">
                   <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Official Sources & Reports</h4>
                   <div className="grid grid-cols-1 gap-4">
                      {result.links.length > 0 ? result.links.map((link: any, i: number) => {
                        if (!link.web && !link.maps) return null;
                        const title = link.web?.title || link.maps?.title || 'External Report';
                        const uri = link.web?.uri || link.maps?.uri || '#';
                        const source = getSourceName(title, uri);
                        
                        return (
                          <a key={i} href={uri} target="_blank" rel="noopener noreferrer" className="p-5 border border-slate-100 bg-white rounded-2xl hover:bg-blue-50 hover:border-blue-100 transition-all flex items-start gap-5 group shadow-sm">
                             <div className={`w-12 h-12 rounded-xl shrink-0 flex items-center justify-center ${link.maps ? 'bg-rose-50 text-rose-500' : 'bg-[#005dab]/5 text-[#005dab]'}`}>
                                <i className={`fas ${link.maps ? 'fa-map-location-dot' : 'fa-newspaper'} text-lg`}></i>
                             </div>
                             <div className="flex-1 min-w-0">
                                <p className="text-[8px] font-black text-[#005dab] uppercase mb-1 tracking-wider opacity-60">{source}</p>
                                <h5 className="text-[11px] font-black text-slate-800 uppercase leading-tight group-hover:text-[#005dab]">{title}</h5>
                                <p className="text-[9px] text-slate-400 font-bold truncate mt-2">{uri}</p>
                             </div>
                             <i className="fas fa-arrow-up-right-from-square text-xs text-slate-300 group-hover:text-blue-500 transition-all mt-1"></i>
                          </a>
                        );
                      }) : (
                        <div className="p-12 border-2 border-dashed border-slate-100 rounded-3xl text-center text-[10px] font-bold text-slate-400 uppercase">
                           No news archives found for this specific zone.
                        </div>
                      )}
                   </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="uidai-card bg-white p-6 sticky top-24">
                 <div className="flex justify-between items-center mb-6">
                    <h4 className="text-[10px] font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                       <i className="fas fa-map-marked-alt text-[#005dab]"></i> Map View
                    </h4>
                    <a href={result.officialMapUri} target="_blank" rel="noopener noreferrer" className="text-[9px] font-black text-[#005dab] uppercase hover:underline">
                       Open Google Maps <i className="fas fa-external-link ml-1"></i>
                    </a>
                 </div>
                 
                 <div className="relative aspect-square rounded-[2rem] overflow-hidden border-4 border-slate-50 shadow-2xl bg-slate-100 group">
                    <iframe 
                      width="100%" 
                      height="100%" 
                      frameBorder="0" 
                      style={{ border: 0 }}
                      src={`https://www.google.com/maps/embed/v1/place?key=REPLACE_ME&q=${encodeURIComponent(result.mapQuery)}`}
                      className="transition-all group-hover:opacity-100"
                      allowFullScreen
                    ></iframe>
                 </div>
              </div>
            </div>
          </div>
        )}

        {loading && (
          <div className="lg:col-span-12 py-32 flex flex-col items-center justify-center">
             <div className="relative mb-8">
                <div className="w-24 h-24 border-8 border-slate-50 border-t-[#005dab] rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                   <i className="fas fa-satellite text-blue-300 text-3xl animate-pulse"></i>
                </div>
             </div>
             <div className="text-center">
                <h4 className="text-xl font-black text-slate-900 uppercase tracking-[0.2em] mb-2">Scanning News Archives</h4>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest animate-pulse">Reading Reports...</p>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};
