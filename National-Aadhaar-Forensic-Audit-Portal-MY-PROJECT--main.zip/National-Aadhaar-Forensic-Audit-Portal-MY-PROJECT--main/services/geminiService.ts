
import { GoogleGenAI, Type } from "@google/genai";
import { AnomalyResult, AadhaarDataRow } from "../types";

export const draftSimpleNotice = async (person: AadhaarDataRow, reasons: string[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `
    A person's Aadhaar record has these issues: ${reasons.join(", ")}.
    Location: ${person.district}, ${person.state}.
    
    Write a very simple message (30 words max) to tell this person their information has a mistake and they need to visit a center to fix it. Use extremely simple words. No scary legal talk.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: "You are a helpful staff member. Use very simple language. Be kind but clear."
      }
    });
    return response.text;
  } catch (error) {
    console.error("Drafting error:", error);
    return "There is a mistake in your record. Please visit your nearest Aadhaar center to check it.";
  }
};

export const analyzeFraudPatterns = async (anomalies: AnomalyResult[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const contextData = anomalies
    .sort((a, b) => b.score - a.score)
    .slice(0, 30)
    .map(a => ({
      district: a.row.district,
      state: a.row.state,
      pincode: a.row.pincode,
      reasons: a.reasons,
      bad_score: (a.score * 100).toFixed(0) + "%"
    }));

  const prompt = `
    Please look at these Aadhaar records that have mistakes or look suspicious.
    
    Data to check:
    ${JSON.stringify(contextData, null, 2)}

    Please tell me:
    1. A very simple summary of what is wrong.
    2. A list of main problems found (use simple titles like "Wrong Age" or "Strange Area").
    3. What we should watch for in the future.
    4. Simple steps to fix these issues.

    Use very simple words. No big office words or tech jargon. Explain it like you are talking to a friend who is new to the job.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        systemInstruction: "You are a helpful Audit Helper. Use very simple, easy language. Avoid technical words. Use language a 10-year-old can understand. Explain things clearly.",
        thinkingConfig: { thinkingBudget: 32768 },
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING },
            patterns: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  riskLevel: { type: Type.STRING },
                  impact: { type: Type.STRING }
                },
                required: ["title", "description", "riskLevel", "impact"]
              }
            },
            predictiveIndicators: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  marker: { type: Type.STRING },
                  forecast: { type: Type.STRING },
                  confidence: { type: Type.STRING }
                },
                required: ["marker", "forecast", "confidence"]
              }
            },
            solutionFrameworks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  strategy: { type: Type.STRING },
                  actionItems: { type: Type.ARRAY, items: { type: Type.STRING } },
                  expectedOutcome: { type: Type.STRING }
                },
                required: ["strategy", "actionItems", "expectedOutcome"]
              }
            }
          },
          required: ["summary", "patterns", "predictiveIndicators", "solutionFrameworks"]
        }
      }
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("AI Analysis Error:", error);
    throw error;
  }
};

export const getRegionalIntel = async (location: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Find simple news about Aadhaar problems in ${location}. Tell me in very simple words what is happening.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });

    return {
      summary: response.text,
      links: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("News Search Error:", error);
    return { summary: "Could not find latest news. Try again later.", links: [] };
  }
};

export const verifyLocationContext = async (district: string, state: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Find info about Aadhaar centers in ${district}, ${state}. Tell me if there are any known problems or big delays in plain language.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleMaps: {} }, { googleSearch: {} }]
      }
    });

    return {
      summary: response.text,
      links: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  } catch (error) {
    console.error("Location Search Error:", error);
    return { summary: "Could not find area details right now.", links: [] };
  }
};
