
import { AadhaarDataRow, AnomalyResult, DatasetStats, DetailedReason } from "../types";

export const parseCSV = (csvText: string): AadhaarDataRow[] => {
  const lines = csvText.split('\n').filter(line => line.trim());
  if (lines.length === 0) return [];

  const headers = lines[0].split(',').map(h => h.trim());
  return lines.slice(1).map(line => {
    const values = line.split(',').map(v => v.trim());
    const row: any = {};
    headers.forEach((header, index) => {
      const val = values[index];
      row[header] = (val === "" || val === undefined) ? null : (isNaN(Number(val)) ? val : Number(val));
    });
    return row as AadhaarDataRow;
  });
};

export const detectAnomalies = (data: AadhaarDataRow[]): { anomalies: AnomalyResult[], stats: DatasetStats } => {
  if (data.length === 0) return { anomalies: [], stats: {} as DatasetStats };

  const allKeys = new Set<string>();
  data.forEach(row => Object.keys(row).forEach(k => allKeys.add(k)));
  
  const numericKeys = Array.from(allKeys).filter(key => {
    const sample = data.find(r => r[key] !== null && r[key] !== undefined)?.[key];
    return typeof sample === 'number';
  });
  
  const columnStats: Record<string, { mean: number, std: number }> = {};
  numericKeys.forEach(key => {
    const values = data.map(row => row[key] as number).filter(v => v !== null && v !== undefined);
    if (values.length < 2) return;
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const std = Math.sqrt(values.map(x => Math.pow(x - mean, 2)).reduce((a, b) => a + b, 0) / values.length);
    columnStats[key] = { mean, std };
  });

  const anomalies: AnomalyResult[] = [];
  const stateCounts: Record<string, number> = {};
  const pincodeCounts: Record<string, number> = {};
  const dateCounts: Record<string, number> = {};

  data.forEach((row, index) => {
    const reasons: string[] = [];
    const detailedReasons: DetailedReason[] = [];
    let maxZScore = 0;

    numericKeys.forEach(key => {
      const stats = columnStats[key];
      if (!stats || stats.std === 0 || row[key] === null || row[key] === undefined) return;
      
      const val = row[key] as number;
      const zScore = Math.abs((val - stats.mean) / stats.std);
      
      // Institutional threshold for anomaly detection (3.0 Sigma)
      if (zScore > 3.0) {
        // Cap importance at 1.0 (10 Sigma = 100% intensity)
        const importance = Math.min(zScore / 10, 1);
        const direction = val > stats.mean ? 'higher' : 'lower';
        const explanation = `Recorded value (${val}) is ${zScore.toFixed(1)} standard deviations ${direction} than the dataset average (${stats.mean.toFixed(2)}).`;
        
        reasons.push(`${key.replace(/_/g, ' ')} Outlier`);
        detailedReasons.push({
          feature: key,
          value: val,
          explanation,
          importance
        });
        maxZScore = Math.max(maxZScore, zScore);
      }
    });

    // Pincode integrity check
    if (row.pincode && String(row.pincode).length !== 6) {
      const explanation = `Statutory format violation: Pincode '${row.pincode}' does not meet the mandatory 6-digit national standard for Indian administrative zones.`;
      reasons.push("Pincode Standard Violation");
      detailedReasons.push({
        feature: 'pincode',
        value: row.pincode,
        explanation,
        importance: 0.95
      });
      maxZScore = Math.max(maxZScore, 5);
    }

    if (detailedReasons.length > 0) {
      detailedReasons.sort((a, b) => b.importance - a.importance);
      
      anomalies.push({
        row,
        index,
        reasons,
        detailedReasons,
        score: Math.min(maxZScore / 10, 1)
      });
    }

    const state = String(row.state || 'Unknown');
    stateCounts[state] = (stateCounts[state] || 0) + 1;
    const pin = String(row.pincode || '000000');
    pincodeCounts[pin] = (pincodeCounts[pin] || 0) + 1;
    
    const date = String(row.date);
    if (date && date !== "undefined" && date !== "null") {
      dateCounts[date] = (dateCounts[date] || 0) + 1;
    }
  });

  const stats: DatasetStats = {
    totalRows: data.length,
    anomalyCount: anomalies.length,
    anomalyRate: (anomalies.length / data.length) * 100,
    topStates: Object.entries(stateCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, value })),
    pincodeHeatmap: Object.entries(pincodeCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([pincode, count]) => ({ pincode, count })),
    ageDistribution: [
      { range: '5-17', count: data.reduce((acc, r) => acc + (Number(r.bio_age_5_17) || 0), 0) },
      { range: '17+', count: data.reduce((acc, r) => acc + (Number(r.bio_age_17_) || 0), 0) }
    ],
    timeSeries: Object.entries(dateCounts)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-30)
  };

  return { anomalies, stats };
};
